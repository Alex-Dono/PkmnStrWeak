package com.pkmn.core

class DamageDealt (val theType: Type, val theMultiplier: Float) {
    val type = theType
    val multiplier = theMultiplier
}
