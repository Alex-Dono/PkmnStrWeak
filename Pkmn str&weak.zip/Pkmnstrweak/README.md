# PkmnStrWeak
